# Dismac Assist — Guía de instalación

Extensión de navegador para Chrome y Microsoft Edge (uso interno Dismac).

## Requisitos
- Google Chrome o Microsoft Edge (escritorio).
- Chrome y Edge usan el mismo formato de extensión. Se instala por separado en cada navegador / equipo.

## Instalación (Chrome)
1. Descomprime el ZIP en una carpeta fija (ej. `C:\Dismac\Dismac Assist`). **No borres la carpeta**; Chrome la necesita cada vez.
2. Abre `chrome://extensions`.
3. Activa el interruptor **"Modo de desarrollador"** (esquina superior derecha).
4. Clic en **"Cargar descomprimida"**.
5. Selecciona la carpeta **`dismac-assist`** (la que contiene `manifest.json`).
6. La extensión aparece instalada. Fija el ícono en la barra si quieres y haz clic en él para abrir el panel lateral.

## Instalación (Microsoft Edge)
1. Descomprime el ZIP en una carpeta fija.
2. Abre `edge://extensions`.
3. Activa **"Modo de desarrollador"** (izquierda).
4. Clic en **"Cargar descomprimida"** y selecciona la carpeta `dismac-assist`.
5. Si Edge muestra avisos de "extensiones de otros orígenes", habilítalos en `edge://settings/extensions` y recarga.

## Notas
- Tras **reiniciar el navegador** la extensión queda instalada.
- Para **actualizar**: reemplaza los archivos de la carpeta con la nueva versión y recarga la extensión en `chrome://extensions` (botón de recarga ↻).
- Al abrir `https://tidywork.dismac.com.bo/*`, el script inyectado se ejecuta automáticamente.
